# Task1_Fruits > 2026-02-15 8:04am
https://universe.roboflow.com/factory-welju/task1_fruits-2pyus

Provided by a Roboflow user
License: CC BY 4.0

